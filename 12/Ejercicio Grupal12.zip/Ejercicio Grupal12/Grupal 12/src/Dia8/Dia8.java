package Dia8;


import java.util.Scanner;

/**
* clase Grupal8
* Solicita datos generales de usuarios de la empresa,
* luego datos específicos según tipo de usuario, para finalmente
* imprimirlos por pantalla
* @CamilaFabbroni @GabrielaMoya @DanielaInostroza @OmarSepúlveda @EnriqueCrespo
* /Bootcamp Desarrollo de Aplicaciones Full Stack Java Trainee v2.0
* @version 0.1, 2023/06/02
*/
public class Dia8 {

	public static void main(String[] args) {

		/**
		 *rut, tipo, cantidadEmpleados, aniosExperiencia: datos de tipo int, 
		 *ingresados por teclado.
		 *nacimiento, nombre, direccion, telefono, funcion, nombreSuperior, departamento:
		 *datos de tipo string, ingresados por teclado.
		 *Exclusiones: campos nulos, repite la instrucción hasta que se ingresa dato.
		 *Condicionante para tipo de usuario (que no corresponda a valor 1, 2 o 3).
		 */
		var scanner = new Scanner(System.in);
		int rut;
		int tipo;
		int cantidadEmpleados;
		int aniosExperiencia;

		String nacimiento;
		String nombre;
		String direccion;
		String telefono;
		String funcion;
		String nombreSuperior;
		String departamento;

		// Solicitar datos generales
		do {
			System.out.print("Inicio del programa, por favor ingresa tu nombre: ");
			nombre = scanner.nextLine();
		} while (nombre.isEmpty());

		do {
			System.out.print("Por favor, " + nombre + ", ingresa tu rut (sin puntos ni guion): ");
			rut = scanner.nextInt();
			scanner.nextLine(); // Limpiar el búfer de entrada
		} while (rut == 0);

		do {
			System.out.print("Por favor, " + nombre + ", ingresa tu fecha de nacimiento en formato xx/xx/xx: ");
			nacimiento = scanner.nextLine();
		} while (nacimiento.isEmpty());

		do {
			System.out.print("Por favor, " + nombre
					+ ", ingresa tu tipo de usuario: cliente(1), administrativo(2), profesional(3): ");
			tipo = scanner.nextInt();
			scanner.nextLine(); // Limpiar el búfer de entrada
		} while (tipo < 1 || tipo > 3);

		switch (tipo) {		// Datos específicos según el tipo de usuario
		case 1: // Cliente
			scanner.nextLine(); // Limpiar el búfer de entrada
			do {
				System.out.print("Por favor, ingresa la direccion de la empresa: ");
				direccion = scanner.nextLine();
			} while (direccion.isEmpty());

			do {
				System.out.print("Por favor, ingresa el telefono de la empresa: ");
				telefono = scanner.nextLine();
			} while (telefono.isEmpty());

			do {
				System.out.print("Por favor, ingresa la cantidad de empleados de la empresa: ");
				cantidadEmpleados = scanner.nextInt();
			} while (cantidadEmpleados == 0);


			System.out.println("Datos ingresados:");
			System.out.println("Nombre: " + nombre);
			System.out.println("RUT: " + rut);
			System.out.println("Fecha de nacimiento: " + nacimiento);
			System.out.println("Tipo de usuario: Cliente");
			System.out.println("Direccion: " + direccion);
			System.out.println("Telefono: " + telefono);
			System.out.println("Cantidad de empleados: " + cantidadEmpleados);
			break;

		case 2: // Administrativo
			scanner.nextLine(); // Limpiar el búfer de entrada

			do {
				System.out.print("Por favor, ingresa la funcion del administrativo: ");
				funcion = scanner.nextLine();
			} while (funcion.isEmpty());

			do {
				System.out.print("Por favor, ingresa el nombre de su superior: ");
				nombreSuperior = scanner.nextLine();
			} while (nombreSuperior.isEmpty());

			System.out.println("Datos ingresados:");
			System.out.println("Nombre: " + nombre);
			System.out.println("RUT: " + rut);
			System.out.println("Fecha de nacimiento: " + nacimiento);
			System.out.println("Tipo de usuario: Administrativo");
			System.out.println("Funcion: " + funcion);
			System.out.println("Nombre superior: " + nombreSuperior);
			break;

		case 3: // Profesional
			scanner.nextLine(); // Limpiar el búfer de entrada

			do {
				System.out.print("Por favor, ingresa los anios de experiencia del profesional: ");
				aniosExperiencia = scanner.nextInt();
			} while (aniosExperiencia == 0);

			scanner.nextLine(); // Limpiar el búfer de entrada

			do {
				System.out.print("Por favor, ingresa el departamento del profesional: ");
				departamento = scanner.nextLine();
			} while (departamento.isEmpty());

			System.out.println("Datos ingresados:");
			System.out.println("Nombre: " + nombre);
			System.out.println("RUT: " + rut);
			System.out.println("Fecha de nacimiento: " + nacimiento);
			System.out.println("Tipo de usuario: Profesional");
			System.out.println("Anios de experiencia: " + aniosExperiencia);
			System.out.println("Departamento: " + departamento);
			break;

		default:
			System.out.println("Tipo de usuario invalido.");
			break;		// Condición de salida para tipo de usuario inválido (que no sea 1,2 o 3)
		}
	}
}
