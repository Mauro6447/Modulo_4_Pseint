package Dia9;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
* clase Grupal9
* Solicita datos de la empresa.
* Solicita datos de la capacitación.
* Solicita datos de los asistentes a la capacitación (nombre y edad).
* Almacena datos de los asistentes en listas.
* Organiza las edades de los asistentes en contadores según rango de edad.
* Finalmente despliega la información por pantalla.
* @CamilaFabbroni @GabrielaMoya @DanielaInostroza @OmarSepúlveda @EnriqueCrespo
* /Bootcamp Desarrollo de Aplicaciones Full Stack Java Trainee v2.0
* @version 0.1, 2023/06/02
*/
public class Dia9 {

	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in)) {
			/**
			*Variables de la Empresa:
			*rut: int, ingresada por teclado 
			*telefono, nombreEmpresa, direccion, comuna: string, ingresadas por teclado.
			 */
			int rut;
			String telefono;
			String nombreEmpresa;
			String direccion;
			String comuna;

			/**
			*Variables de la Capacitación:
			*duracion: int, ingresada por teclado 
			*dia, hora, lugar: string, ingresadas por teclado.
			*/
			String dia;
			String hora;
			String lugar;
			int duracion;

			/**
			*Variables de los asistentes:
			*edadAsistente: int, ingresada por teclado 
			*nombreAsistente: string, ingresadas por teclado.
			*nombresAsistentes: Arraylist, string , lista de los nombres de los asistentes
			*edadesAsistentes: Arraylist, string , lista de las edades de los asistentes
			*/
			int cantidadAsistentes;
			String nombreAsistente;
			List<String> nombresAsistentes = new ArrayList<>();
			int edadAsistente;
			List<Integer> edadesAsistentes = new ArrayList<>();

			// Variables de contadores
			int menores25 = 0;
			int entre25y35 = 0;
			int mayores35 = 0;

			System.out.println("Ingrese los datos de la empresa:");	// Ingreso de datos de la empresa
			do {
				System.out.print("RUT: ");
				rut = scanner.nextInt();
			} while (rut == 0);

			scanner.nextLine(); // Limpiar el buffer

			do {
				System.out.print("Nombre: ");
				nombreEmpresa = scanner.nextLine();
			} while (nombreEmpresa.isEmpty());

			do {
				System.out.print("Direccion: ");
				direccion = scanner.nextLine();
			} while (direccion.isEmpty());

			do {
				System.out.print("Comuna: ");
				comuna = scanner.nextLine();
			} while (comuna.isEmpty());

			do {
				System.out.print("Telefono: ");
				telefono = scanner.nextLine();
			} while (telefono.isEmpty());

			System.out.println("\nIngrese los datos de la capacitacion:");	// Ingreso de datos de la capacitación
			do {
				System.out.print("Dia: ");
				dia = scanner.nextLine();
			} while (dia.isEmpty());

			do {
				System.out.print("Hora: ");
				hora = scanner.nextLine();
			} while (hora.isEmpty());

			do {
				System.out.print("Lugar: ");
				lugar = scanner.nextLine();
			} while (lugar.isEmpty());

			do {
				System.out.print("Duracion (numero de horas): ");
				duracion = scanner.nextInt();
			} while (duracion == 0);

			do {
				System.out.print("Cantidad de asistentes (mayor que cero): "); // Validación de la cantidad de asistentes
				cantidadAsistentes = scanner.nextInt();
			} while (cantidadAsistentes < 0);

			scanner.nextLine(); // Limpiar el buffer

			System.out.println("\nIngrese los datos de los asistentes:"); // Registro de los asistentes
			for (int i = 0; i < cantidadAsistentes; i++) {
				do {
					System.out.print("Nombre del asistente " + (i + 1) + ": ");
					nombreAsistente = scanner.nextLine();
				} while (nombreAsistente.isEmpty());

				do {
					System.out.print("Edad del asistente " + (i + 1) + ": ");
					edadAsistente = scanner.nextInt();
				} while (edadAsistente < 0);

				scanner.nextLine(); // Limpiar el buffer

				nombresAsistentes.add(nombreAsistente);
				edadesAsistentes.add(edadAsistente);

				if (edadAsistente < 25) {
					menores25++;
				} else if (edadAsistente >= 25 && edadAsistente <= 35) {
					entre25y35++;
				} else {
					mayores35++;
				}
			}

			System.out.println("\nDatos de la empresa:");
			System.out.println("RUT: " + rut);
			System.out.println("Nombre: " + nombreEmpresa);
			System.out.println("Direccion: " + direccion);
			System.out.println("Comuna: " + comuna);
			System.out.println("Telefono: " + telefono);

			System.out.println("\nDatos de la capacitacion:");
			System.out.println("Dia: " + dia);
			System.out.println("Hora: " + hora);
			System.out.println("Lugar: " + lugar);
			System.out.println("Duracion: " + duracion + " horas");

			System.out.println("\nCantidad de personas en cada rango de edad:");
			System.out.println("Menores a 25 anios: " + menores25);
			System.out.println("Entre 25 y 35 anios: " + entre25y35);
			System.out.println("Mayores a 35 anios: " + mayores35);
		}
	}
}

