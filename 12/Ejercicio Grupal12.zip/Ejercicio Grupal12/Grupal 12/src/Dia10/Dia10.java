package Dia10;

import java.util.Scanner;

/**
* clase Grupal10
* Solicita datos de la capacitación
* Solicita datos de los asistentes a la capacitación
* (cantidad de asistentes, nombres y calificación que entregan a la capacitación)
* Almacena nombre y calificación de asistentes en una matriz
* Determina el promedio de las calificaciones y el menor y mayor valor
* Finalmente despliega la información por pantalla
* @CamilaFabbroni @GabrielaMoya @DanielaInostroza @OmarSepúlveda @EnriqueCrespo
* /Bootcamp Desarrollo de Aplicaciones Full Stack Java Trainee v2.0
* @version 0.1, 2023/06/02
*/
public class Dia10 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		/**
		*Variables de la Capacitación:
		*duracion: int, ingresada por teclado 
		*dia, hora, lugar: string, ingresadas por teclado.
		*/
		String dia;
		String hora;
		String lugar;
		int duracion;

		/**
		*Variables de los asistentes:
		*cantidadAsistentes: int, ingresada por teclado 
		*calificacion: int, ingresada por teclado
		*nombreAsistente: string, ingresada por teclado
		*String[][] asistentes: matriz tipo string, almacena nombres y calificaciones
		*calificacionMinima: int, calificacion mínima otorgada por los asistentes
		*calificacionMaxima: int, calificacion máxima otorgada por los asistentes
		*sumaCalificaciones: int, suma de las calificaciones
		*/
		int cantidadAsistentes;
		String[][] asistentes;
		int sumaCalificaciones;
		int calificacionMinima;
		int calificacionMaxima;

		boolean calificacionValida;	// Variable de validación de calificaciones

		System.out.println("\nIngrese los datos de la capacitacion:");	// Ingreso de datos de la capacitación
		do {
			System.out.print("Dia: ");
			dia = scanner.nextLine();
		} while (dia.isEmpty());

		do {
			System.out.print("Hora: ");
			hora = scanner.nextLine();
		} while (hora.isEmpty());

		do {
			System.out.print("Lugar: ");
			lugar = scanner.nextLine();
		} while (lugar.isEmpty());

		do {
			System.out.print("Duracion (numero de horas): ");
			duracion = scanner.nextInt();
		} while (duracion == 0);

		do {
			System.out.print("Cantidad de asistentes (mayor que cero): ");
			while (!scanner.hasNextInt()) {
				System.out.println("Debe ingresar un número valido.");
				scanner.next(); // Validación de la cantidad de asistentes
			}
			cantidadAsistentes = scanner.nextInt();
		} while (cantidadAsistentes <= 0);

		scanner.nextLine();

		asistentes = new String[cantidadAsistentes][4]; // Crear matriz para almacenar los nombres y las calificaciones

		sumaCalificaciones = 0; // Inicializar variables de calificaciones
		calificacionMinima = Integer.MAX_VALUE;
		calificacionMaxima = Integer.MIN_VALUE;

		for (int i = 0; i < cantidadAsistentes; i++) {
			System.out.print("\nNombre del asistente " + (i + 1) + ": ");
			String nombreAsistente;
			do {
				nombreAsistente = scanner.nextLine();
			} while (nombreAsistente.isEmpty()); // Ingreso de datos de los asistentes y calificaciones

			asistentes[i][0] = nombreAsistente;

			calificacionValida = false;
			do {
				System.out.print("Calificacion (1-7): ");
				String calificacionStr = scanner.nextLine();
				if (!calificacionStr.isEmpty()) {
					try {
						int calificacion = Integer.parseInt(calificacionStr);
						if (calificacion >= 1 && calificacion <= 7) {
							asistentes[i][1] = calificacionStr;
							calificacionValida = true; // Validación de rango para la calificación

							int calificacionInt = Integer.parseInt(calificacionStr);
							sumaCalificaciones += calificacionInt;
							if (calificacionInt < calificacionMinima) {
								calificacionMinima = calificacionInt;
							}
							if (calificacionInt > calificacionMaxima) {
								calificacionMaxima = calificacionInt;
							}
						} else {
							System.out.println("La calificacion debe estar entre 1 y 7.");
						}
					} catch (NumberFormatException e) {
						System.out.println("Debe ingresar un numero valido.");
					}
				} else {
					System.out.println("Debe ingresar una calificacion.");
				}
			} while (!calificacionValida);
		} // Actualizar variables de calificaciones

		double promedioCalificaciones = (double) sumaCalificaciones / cantidadAsistentes;

		System.out.println("\n--- Datos de la capacitacion ---");
		System.out.println("Dia: " + dia);
		System.out.println("Hora: " + hora);
		System.out.println("Lugar: " + lugar);
		System.out.println("Duracion: " + duracion + " horas");

		System.out.println("\n--- Resultados de las calificaciones ---");
		System.out.println("Promedio de calificaciones: " + promedioCalificaciones);
		System.out.println("Calificacion maxima: " + calificacionMaxima);
		System.out.println("Calificacion minima: " + calificacionMinima);
	}
}
